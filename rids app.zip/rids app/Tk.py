import cv2
import numpy as np
import pyttsx3
from ultralytics import YOLO

if __name__ == "__main__":
    net = cv2.dnn.readNet("yolov8n.onnx")
    print(net)
    classes = []
    with open("coco.names", "r") as f:
        classes = [line.strip() for line in f.readlines()]

    # Initialize pyttsx3
    engine = pyttsx3.init()

    # Function to convert text to speech
    def speak(text):
        engine.say(text)
        engine.runAndWait()

    # Read video stream
    cap = cv2.VideoCapture(0)  # Change to your video source if needed

    while True:
        _, img = cap.read()
        height, width, channels = img.shape

        # Detecting objects
        blob = cv2.dnn.blobFromImage(img, 1/255, (640, 640), (0, 0, 0), True, crop=False)
        net.setInput(blob)
        outs = net.forward()
        outs = outs.transpose((0, 2, 1))

        # Showing information on the screen
        class_ids = []
        confidences = []
        boxes = []

        rows = outs[0].shape[0]

        for i in range(rows):
            row = outs[0][i]
            conf = row[4]
            scores = row[4:]
            _,_,_, max_idx = cv2.minMaxLoc(scores)
            class_id = max_idx[1]
            
            confidence = scores[class_id]
            if confidence > 0.5 :
                # Extract class ID
                # Retrieve class name using class ID
                class_name = classes[int(class_id)]
                
                # Object detected
                x, y, w, h = row[0].item(), row[1].item(), row[2].item(), row[3].item()
                
                left = int((x - 0.5 * w))
                top = int((y - 0.5 * h))
                
                width = int(w)
                height = int(h)
                
                box = np.array([left, top, width, height])
                boxes.append(box)
                confidences.append(float(confidence))
                class_ids.append(class_id)
                    
        r_class_ids, r_confs, r_boxes = list(), list(), list()
        indexes = cv2.dnn.NMSBoxes(boxes, confidences, 0.5, 0.4)

        for i in indexes:
            r_class_ids.append(class_ids[i])
            r_confs.append(confidences[i])
            r_boxes.append(boxes[i])

        for i in indexes:
            box = boxes[i]
            left = box[0]
            top = box[1]
            width = box[2]
            height = box[3]

            label = r_class_ids[np.where(indexes == i)[0][0]]
            label = classes[label]
            
            confidence = r_confs[np.where(indexes == i)[0][0]]
            
            cv2.rectangle(img, (left, top), (left + width, top + height), (0,255,0), 3)
            cv2.putText(img, label + " " + str(round(confidence, 2)), (left, top + 30), cv2.FONT_HERSHEY_PLAIN, 3, (0,255,0), 3)
            speak("I see a " + label)
            cv2.imshow("Webcam", img)
        
        if cv2.waitKey(1) == ord("q"):
            break

    cap.release()
cv2.destroyAllWindows()
